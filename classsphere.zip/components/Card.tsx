
import React from 'react';

interface CardProps {
    title: string;
    icon: React.ReactNode;
    children: React.ReactNode;
    className?: string;
}

const Card: React.FC<CardProps> = ({ title, icon, children, className }) => {
    return (
        <div className={`bg-white dark:bg-gray-800/80 rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300 ${className}`}>
            <div className="flex items-center gap-3 mb-4">
                <div className="bg-primary/10 dark:bg-primary/20 p-2 rounded-lg text-primary dark:text-secondary">
                   {icon}
                </div>
                <h2 className="text-xl font-bold text-charcoal dark:text-soft-grey">{title}</h2>
            </div>
            <div>{children}</div>
        </div>
    );
};

export default Card;
