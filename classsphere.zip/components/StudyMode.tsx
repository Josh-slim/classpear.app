
import React from 'react';
import { Page } from '../types';
import { SUBJECTS, CONTINUE_LEARNING, RECOMMENDED_TODAY, LESSON_CONTENT } from '../constants';
import Card from './Card';
import { BookOpenIcon, SparklesIcon, DocumentTextIcon, CalendarDaysIcon } from './icons';

interface StudyModeProps {
    setPage: (page: Page) => void;
    viewLesson: (lesson: {title: string, subject: string}) => void;
}

const StudyMode: React.FC<StudyModeProps> = ({ setPage, viewLesson }) => {
    return (
        <div className="p-4 md:p-8 space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-charcoal dark:text-soft-grey">Study Mode</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-1">Focus on what matters most for your exams.</p>
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-r from-primary to-accent text-white shadow-lg cursor-pointer" onClick={() => viewLesson({title: "Forces", subject: "Physics"})}>
                <h3 className="text-lg">Continue Learning</h3>
                <p className="text-2xl font-bold">{CONTINUE_LEARNING.subject} - {CONTINUE_LEARNING.topic}</p>
                <div className="w-full bg-white/20 rounded-full h-2.5 mt-3">
                    <div className="bg-white h-2.5 rounded-full" style={{ width: `${CONTINUE_LEARNING.progress}%` }}></div>
                </div>
            </div>

            <Card title="Subjects" icon={<BookOpenIcon className="w-6 h-6" />}>
                <div className="flex flex-wrap gap-3">
                    {SUBJECTS.map(subject => (
                        <button key={subject} className="bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey font-semibold py-2 px-4 rounded-lg hover:bg-secondary hover:text-charcoal transition-colors">
                            {subject}
                        </button>
                    ))}
                </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 <Card title="Study Tools" icon={<SparklesIcon className="w-6 h-6" />}>
                    <div className="flex flex-wrap gap-3">
                        {['Flashcards', 'Practice', 'Notes', 'Planner'].map(tool => (
                            <button key={tool} className="bg-primary/10 dark:bg-primary/20 text-primary dark:text-secondary font-bold py-2 px-4 rounded-lg hover:bg-primary hover:text-white transition-colors flex-1">
                                {tool}
                            </button>
                        ))}
                    </div>
                </Card>
                <Card title="Recommended Today" icon={<CalendarDaysIcon className="w-6 h-6" />} className="lg:col-span-2">
                    <ul className="space-y-3">
                        {RECOMMENDED_TODAY.map(item => (
                             <li key={item.id} onClick={() => viewLesson(LESSON_CONTENT)} className="flex justify-between items-center p-3 rounded-md bg-soft-grey dark:bg-gray-700/50 cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                                <div>
                                    <p className="font-semibold text-charcoal dark:text-soft-grey">{item.title}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">{item.subject}</p>
                                </div>
                                <button className="text-primary dark:text-secondary font-semibold text-sm">Start</button>
                            </li>
                        ))}
                    </ul>
                </Card>
            </div>

        </div>
    );
};

export default StudyMode;
