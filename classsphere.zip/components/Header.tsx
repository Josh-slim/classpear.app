
import React from 'react';
import { User, UserRole } from '../types';
import { SunIcon, MoonIcon, ChevronDownIcon, UserCircleIcon, AcademicCapIcon } from './icons';

interface HeaderProps {
    user: User;
    isDarkMode: boolean;
    toggleDarkMode: () => void;
    userRole: UserRole;
    onRoleChange: (role: UserRole) => void;
}

const Header: React.FC<HeaderProps> = ({ user, isDarkMode, toggleDarkMode, userRole, onRoleChange }) => {
    return (
        <header className="bg-white dark:bg-gray-800/50 backdrop-blur-sm shadow-sm p-4 flex items-center justify-between flex-shrink-0 z-10 border-b border-soft-grey dark:border-charcoal/50">
            <div>
                <h1 className="text-xl font-bold text-charcoal dark:text-soft-grey">ClassSphere</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">Learn Live. Learn Anytime.</p>
            </div>
            <div className="flex items-center gap-4">
                 <div className="relative">
                    <select 
                        value={userRole} 
                        onChange={(e) => onRoleChange(e.target.value as UserRole)}
                        className="bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey rounded-md py-2 pl-3 pr-8 appearance-none focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                        <option value="student">Student</option>
                        <option value="teacher">Teacher</option>
                    </select>
                    <ChevronDownIcon className="w-4 h-4 absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 dark:text-gray-400 pointer-events-none" />
                 </div>

                <button onClick={toggleDarkMode} className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-soft-grey dark:hover:bg-gray-700 transition-colors">
                    {isDarkMode ? <SunIcon className="w-6 h-6" /> : <MoonIcon className="w-6 h-6 text-primary" />}
                </button>
                <div className="flex items-center gap-2">
                    <img src={user.avatarUrl} alt={user.name} className="w-10 h-10 rounded-full" />
                    <div>
                        <p className="font-semibold text-charcoal dark:text-soft-grey">{user.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 capitalize flex items-center gap-1">
                             {userRole === 'student' ? <UserCircleIcon className="w-4 h-4"/> : <AcademicCapIcon className="w-4 h-4"/>}
                            {userRole}
                        </p>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
