
import React from 'react';
import { Page, UserRole } from '../types';
import { HomeIcon, PlayCircleIcon, BookOpenIcon, DocumentTextIcon, AcademicCapIcon, UserCircleIcon, BeakerIcon } from './icons';

interface SidebarProps {
    userRole: UserRole;
    currentPage: Page;
    setPage: (page: Page) => void;
}

const NavItem: React.FC<{ icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }> = ({ icon, label, isActive, onClick }) => (
    <li
        onClick={onClick}
        className={`flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer transition-all duration-200 ${
            isActive 
                ? 'bg-primary text-white shadow-lg' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-primary/10 hover:text-primary dark:hover:bg-primary/20 dark:hover:text-white'
        }`}
    >
        {icon}
        <span className="font-semibold">{label}</span>
    </li>
);

const STUDENT_NAV: { page: Page; label: string; icon: React.ReactNode }[] = [
    { page: 'dashboard', label: 'Home', icon: <HomeIcon className="w-6 h-6" /> },
    { page: 'live', label: 'Live Classes', icon: <PlayCircleIcon className="w-6 h-6" /> },
    { page: 'study', label: 'Study Mode', icon: <BookOpenIcon className="w-6 h-6" /> },
    { page: 'assignments', label: 'Assignments', icon: <DocumentTextIcon className="w-6 h-6" /> },
    { page: 'grades', label: 'Grades', icon: <AcademicCapIcon className="w-6 h-6" /> },
];

const TEACHER_NAV: { page: Page; label: string; icon: React.ReactNode }[] = [
    { page: 'dashboard', label: 'Dashboard', icon: <HomeIcon className="w-6 h-6" /> },
    { page: 'live', label: 'Live Classes', icon: <PlayCircleIcon className="w-6 h-6" /> },
    { page: 'materials', label: 'Materials', icon: <BookOpenIcon className="w-6 h-6" /> },
    { page: 'assignments', label: 'Assignments', icon: <DocumentTextIcon className="w-6 h-6" /> },
    { page: 'tests', label: 'Quizzes', icon: <BeakerIcon className="w-6 h-6" /> },
];

const Sidebar: React.FC<SidebarProps> = ({ userRole, currentPage, setPage }) => {
    const navItems = userRole === 'student' ? STUDENT_NAV : TEACHER_NAV;

    return (
        <aside className="w-64 bg-white dark:bg-gray-800/50 p-6 flex-shrink-0 flex flex-col justify-between border-r border-soft-grey dark:border-charcoal/50">
            <nav>
                <ul className="space-y-2">
                    {navItems.map(item => (
                        <NavItem 
                            key={item.page}
                            label={item.label} 
                            icon={item.icon}
                            isActive={currentPage === item.page} 
                            onClick={() => setPage(item.page)}
                        />
                    ))}
                </ul>
            </nav>
            <div className="p-4 bg-primary/10 dark:bg-primary/20 rounded-lg text-center">
                 <p className="text-primary dark:text-secondary font-bold">ClassSphere</p>
                 <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">© 2024. All rights reserved.</p>
            </div>
        </aside>
    );
};

export default Sidebar;
