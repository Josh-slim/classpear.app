
import React, { useState, useRef, useEffect } from 'react';
import { getTutorResponse } from '../services/geminiService';
import { SparklesIcon, XMarkIcon, PaperAirplaneIcon } from './icons';

interface AiTutorProps {
    lesson: {title: string, subject: string} | null;
    isOpen: boolean;
    setIsOpen: (isOpen: boolean) => void;
}

interface Message {
    sender: 'user' | 'ai';
    text: string;
}

const AiTutor: React.FC<AiTutorProps> = ({ lesson, isOpen, setIsOpen }) => {
    const [messages, setMessages] = useState<Message[]>([
        { sender: 'ai', text: `Hi! I'm your AI tutor. How can I help you with "${lesson?.title || 'this lesson'}" today?` }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;
        
        const userMessage: Message = { sender: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        const aiResponseText = await getTutorResponse(input, lesson?.title || 'the current topic');
        const aiMessage: Message = { sender: 'ai', text: aiResponseText };
        
        setMessages(prev => [...prev, aiMessage]);
        setIsLoading(false);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed bottom-8 right-8 w-full max-w-md h-[70vh] max-h-[600px] bg-white dark:bg-charcoal rounded-2xl shadow-2xl flex flex-col z-50 transform transition-transform duration-300 scale-100">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-soft-grey dark:border-gray-700 flex-shrink-0">
                <div className="flex items-center gap-2">
                    <SparklesIcon className="w-6 h-6 text-accent" />
                    <h3 className="font-bold text-lg text-charcoal dark:text-soft-grey">ClassSphere AI Tutor</h3>
                </div>
                <button onClick={() => setIsOpen(false)} className="p-1 rounded-full hover:bg-soft-grey dark:hover:bg-gray-700">
                    <XMarkIcon className="w-6 h-6 text-gray-500 dark:text-gray-400" />
                </button>
            </div>

            {/* Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {messages.map((msg, index) => (
                    <div key={index} className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        {msg.sender === 'ai' && <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-5 h-5 text-white"/></div>}
                        <div className={`max-w-xs md:max-w-sm rounded-2xl px-4 py-3 ${msg.sender === 'user' ? 'bg-primary text-white rounded-br-none' : 'bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey rounded-bl-none'}`}>
                           <p className="text-sm">{msg.text}</p>
                        </div>
                    </div>
                ))}
                {isLoading && (
                     <div className="flex gap-3 justify-start">
                        <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-5 h-5 text-white"/></div>
                        <div className="max-w-xs md:max-w-sm rounded-2xl px-4 py-3 bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey rounded-bl-none">
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-75"></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-150"></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-300"></div>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-soft-grey dark:border-gray-700 flex-shrink-0">
                <div className="relative">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Ask a question..."
                        className="w-full bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey rounded-full py-3 pl-4 pr-12 focus:outline-none focus:ring-2 focus:ring-primary"
                        disabled={isLoading}
                    />
                    <button onClick={handleSend} disabled={isLoading} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-primary text-white disabled:bg-gray-400 hover:bg-primary/90 transition-colors">
                        <PaperAirplaneIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AiTutor;
