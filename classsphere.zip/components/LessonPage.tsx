
import React from 'react';
import { LESSON_CONTENT } from '../constants';
import { SparklesIcon } from './icons';

interface LessonPageProps {
    lesson: {title: string, subject: string} | null;
    setTutorOpen: (isOpen: boolean) => void;
}

const LessonPage: React.FC<LessonPageProps> = ({ lesson, setTutorOpen }) => {
    const content = lesson ? { ...LESSON_CONTENT, title: lesson.title, subject: lesson.subject } : LESSON_CONTENT;

    return (
        <div className="p-4 md:p-8">
            <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                    <p className="text-primary dark:text-secondary font-semibold">{content.subject}</p>
                    <h1 className="text-4xl font-bold text-charcoal dark:text-soft-grey mt-1">{content.title}</h1>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="md:col-span-2">
                        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6">
                            <h2 className="text-2xl font-bold text-charcoal dark:text-soft-grey mb-4">Lesson Content</h2>
                            <div className="aspect-w-16 aspect-h-9 mb-6">
                                <iframe 
                                    className="rounded-lg w-full h-full"
                                    src="https://www.youtube.com/embed/fNk_zzaMoSs" 
                                    title="YouTube video player" 
                                    frameBorder="0" 
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                    allowFullScreen>
                                </iframe>
                            </div>
                            <p className="text-gray-600 dark:text-gray-300">
                                This lesson provides a comprehensive overview of {content.title}. Watch the video and review the key notes to get started.
                            </p>
                        </div>
                    </div>

                    <div className="md:col-span-1 space-y-4">
                        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6">
                            <h3 className="font-bold text-charcoal dark:text-soft-grey mb-3">Lesson Outline</h3>
                            <ul className="space-y-2">
                                {content.components.map((item, index) => (
                                    <li key={index} className="text-gray-700 dark:text-gray-300 flex items-center gap-2">
                                        <div className={`w-2 h-2 rounded-full ${index < 2 ? 'bg-accent' : 'bg-gray-300 dark:bg-gray-600'}`}></div>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                         <button className="w-full bg-soft-grey dark:bg-gray-700 font-bold py-3 px-4 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors text-charcoal dark:text-soft-grey">
                           Mark as Complete
                        </button>
                    </div>
                </div>

                <div className="fixed bottom-8 right-8 z-20">
                    <button 
                        onClick={() => setTutorOpen(true)}
                        className="flex items-center gap-3 bg-gradient-to-r from-accent to-primary text-white font-bold py-4 px-6 rounded-full shadow-2xl hover:scale-105 transform transition-transform duration-300"
                    >
                        <SparklesIcon className="w-6 h-6" /> Ask AI Tutor
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LessonPage;
