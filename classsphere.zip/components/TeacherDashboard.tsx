import React, { useState } from 'react';
import { Teacher, LessonPlan } from '../types';
import { getLessonPlan } from '../services/geminiService';
import Card from './Card';
import { CalendarDaysIcon, SparklesIcon } from './icons';

interface TeacherDashboardProps {
    user: Teacher;
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ user }) => {
    const [subject, setSubject] = useState('Physics');
    const [topic, setTopic] = useState("Newton's First Law");
    const [duration, setDuration] = useState('45 minutes');
    const [lessonPlan, setLessonPlan] = useState<LessonPlan | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);

    const handleGeneratePlan = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsGenerating(true);
        setLessonPlan(null);
        const plan = await getLessonPlan(subject, topic, duration);
        setLessonPlan(plan);
        setIsGenerating(false);
    };

    return (
        <div className="p-4 md:p-8 space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-charcoal dark:text-soft-grey">Welcome, {user.name}</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-1">Here's what's happening today.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card title="Today's Schedule" icon={<CalendarDaysIcon className="w-6 h-6" />}>
                     <ul className="space-y-3">
                        <li className="flex justify-between items-center p-3 rounded-md bg-soft-grey dark:bg-gray-700/50">
                            <div>
                                <p className="font-semibold text-charcoal dark:text-soft-grey">Grade 10 Biology</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">Live Class at 1:00 PM</p>
                            </div>
                            <button className="text-primary dark:text-secondary font-semibold text-sm">Start</button>
                        </li>
                        <li className="flex justify-between items-center p-3 rounded-md bg-soft-grey dark:bg-gray-700/50">
                             <div>
                                <p className="font-semibold text-charcoal dark:text-soft-grey">Grade 11 Chemistry</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">Upload Lesson Materials</p>
                            </div>
                            <button className="text-primary dark:text-secondary font-semibold text-sm">Manage</button>
                        </li>
                    </ul>
                </Card>

                <Card title="AI Lesson Planner" icon={<SparklesIcon className="w-6 h-6" />} className="lg:row-span-2">
                    <form onSubmit={handleGeneratePlan} className="space-y-4 mb-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Subject</label>
                            <input type="text" value={subject} onChange={e => setSubject(e.target.value)} className="w-full bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Topic</label>
                            <input type="text" value={topic} onChange={e => setTopic(e.target.value)} className="w-full bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Duration</label>
                            <input type="text" value={duration} onChange={e => setDuration(e.target.value)} className="w-full bg-soft-grey dark:bg-gray-700 text-charcoal dark:text-soft-grey rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary" />
                        </div>
                        <button type="submit" disabled={isGenerating} className="flex items-center justify-center gap-2 w-full bg-accent text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-accent/90 transition-all duration-300 disabled:bg-gray-400">
                            <SparklesIcon className="w-5 h-5" />
                            {isGenerating ? 'Generating...' : 'Generate Lesson Plan'}
                        </button>
                    </form>
                    
                    {isGenerating && (
                        <div className="flex justify-center items-center h-48">
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                            <p className="ml-4 text-gray-600 dark:text-gray-300">Creating your lesson plan...</p>
                        </div>
                    )}

                    {lessonPlan && (
                        <div className="space-y-4 animate-fade-in">
                           <h3 className="text-lg font-bold text-charcoal dark:text-soft-grey border-b pb-2">Generated Plan for: {topic}</h3>
                           <div>
                                <h4 className="font-semibold text-charcoal dark:text-soft-grey mb-2">Learning Objectives</h4>
                                <ul className="list-disc list-inside space-y-1 text-gray-600 dark:text-gray-300">
                                    {lessonPlan.learningObjectives.map((obj, i) => <li key={i}>{obj}</li>)}
                                </ul>
                           </div>
                           <div>
                                <h4 className="font-semibold text-charcoal dark:text-soft-grey mb-2">Key Concepts</h4>
                                <ul className="list-disc list-inside space-y-1 text-gray-600 dark:text-gray-300">
                                    {lessonPlan.keyConcepts.map((concept, i) => <li key={i}>{concept}</li>)}
                                </ul>
                           </div>
                           <div>
                                <h4 className="font-semibold text-charcoal dark:text-soft-grey mb-2">Activities</h4>
                                <ul className="space-y-3">
                                    {lessonPlan.activities.map((activity, i) => (
                                        <li key={i} className="p-3 rounded-md bg-soft-grey dark:bg-gray-700/50">
                                            <div className="flex justify-between items-start">
                                                <p className="font-bold text-charcoal dark:text-soft-grey">{activity.name}</p>
                                                <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">{activity.time}</span>
                                            </div>
                                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{activity.description}</p>
                                        </li>
                                    ))}
                                </ul>
                           </div>
                            <div>
                                <h4 className="font-semibold text-charcoal dark:text-soft-grey mb-2">Assessment</h4>
                                <p className="text-gray-600 dark:text-gray-300">{lessonPlan.assessment}</p>
                           </div>
                        </div>
                    )}
                </Card>
            </div>
        </div>
    );
};

export default TeacherDashboard;
