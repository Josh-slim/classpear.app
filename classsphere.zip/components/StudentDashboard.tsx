
import React, { useState } from 'react';
import { Student, Page, StudyRecommendation } from '../types';
import { SCHEDULE, ASSIGNMENTS } from '../constants';
import { getStudyPlan } from '../services/geminiService';
import Card from './Card';
import { CalendarDaysIcon, PencilIcon, ChartBarIcon, PlayCircleIcon, BookOpenIcon, SparklesIcon } from './icons';

interface StudentDashboardProps {
    user: Student;
    setPage: (page: Page) => void;
    viewLesson: (lesson: {title: string, subject: string}) => void;
}

const subjectColors: {[key: string]: string} = {
    'Math': '#2F54EB',
    'Physics': '#9D4FF4',
    'Biology': '#3CCFCF',
    'Chemistry': '#FACC15',
    'History': '#F97316',
    'English': '#EC4899',
    'Any': '#6B7280',
};

const getSubjectColor = (subject: string) => {
    return subjectColors[subject] || subjectColors['Any'];
};

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user, setPage, viewLesson }) => {
    const [recommendations, setRecommendations] = useState<StudyRecommendation[]>([]);
    const [isGenerating, setIsGenerating] = useState(false);
    const [planGenerated, setPlanGenerated] = useState(false);

    const greeting = () => {
        const hour = new Date().getHours();
        if (hour < 12) return 'Good Morning';
        if (hour < 18) return 'Good Afternoon';
        return 'Good Evening';
    };

    const handleGeneratePlan = async () => {
        setIsGenerating(true);
        setRecommendations([]);
        const plan = await getStudyPlan(user);
        setRecommendations(plan);
        setIsGenerating(false);
        setPlanGenerated(true);
    };

    return (
        <div className="p-4 md:p-8 space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-charcoal dark:text-soft-grey">{greeting()}, {user.name} 👋</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-1">Ready to learn something new today?</p>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center gap-4">
                <button onClick={() => setPage('live')} className="w-full sm:w-auto flex items-center justify-center gap-2 bg-primary text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-primary/90 transition-all duration-300">
                    <PlayCircleIcon className="w-6 h-6" /> Join Live Class
                </button>
                <button onClick={() => setPage('study')} className="w-full sm:w-auto flex items-center justify-center gap-2 bg-secondary text-charcoal font-bold py-3 px-6 rounded-lg shadow-md hover:bg-secondary/90 transition-all duration-300">
                    <BookOpenIcon className="w-6 h-6" /> Study on Your Own
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card title="Today's Schedule" icon={<CalendarDaysIcon className="w-6 h-6" />} className="lg:col-span-1">
                    <ul className="space-y-3">
                        {SCHEDULE.map(course => (
                            <li key={course.id} className="flex justify-between items-center p-3 rounded-md bg-soft-grey dark:bg-gray-700/50">
                                <div>
                                    <p className="font-semibold text-charcoal dark:text-soft-grey">{course.subject}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">{course.time}</p>
                                </div>
                                <button className="text-primary dark:text-secondary font-semibold text-sm">Join</button>
                            </li>
                        ))}
                    </ul>
                </Card>
                <Card title="Assignments" icon={<PencilIcon className="w-6 h-6" />} className="lg:col-span-1">
                     <ul className="space-y-3">
                        {ASSIGNMENTS.map(assignment => (
                            <li key={assignment.id} className="flex justify-between items-center p-3 rounded-md bg-soft-grey dark:bg-gray-700/50">
                                <div>
                                    <p className="font-semibold text-charcoal dark:text-soft-grey">{assignment.title}</p>
                                    <p className="text-sm text-red-500">Due: {assignment.dueDate}</p>
                                </div>
                                <button className="text-primary dark:text-secondary font-semibold text-sm">View</button>
                            </li>
                        ))}
                    </ul>
                </Card>
                 <Card title="Your Daily Study Plan" icon={<ChartBarIcon className="w-6 h-6" />} className="lg:col-span-1">
                    {!planGenerated && !isGenerating && (
                        <div className="text-center p-4">
                            <p className="text-gray-600 dark:text-gray-400 mb-4">Get a personalized study plan for today, powered by AI.</p>
                            <button 
                                onClick={handleGeneratePlan}
                                className="flex items-center justify-center gap-2 w-full bg-accent text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-accent/90 transition-all duration-300"
                            >
                                <SparklesIcon className="w-5 h-5" />
                                Generate My Plan
                            </button>
                        </div>
                    )}
                    {isGenerating && (
                        <div className="flex justify-center items-center h-48">
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                        </div>
                    )}
                    {planGenerated && !isGenerating && (
                        <ul className="space-y-3">
                            {recommendations.map(rec => (
                                <li 
                                    key={rec.id} 
                                    onClick={() => viewLesson({ title: rec.title, subject: rec.subject })}
                                    className="p-3 rounded-lg bg-soft-grey dark:bg-gray-700/50 cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                                >
                                    <div className="flex justify-between items-start">
                                        <div className="flex-1 pr-2">
                                            <p className="font-bold text-charcoal dark:text-soft-grey">{rec.title}</p>
                                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{rec.description}</p>
                                        </div>
                                        <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 whitespace-nowrap">{rec.estimatedTime}</span>
                                    </div>
                                    <div className="mt-2">
                                    <span className="text-xs font-bold capitalize text-white px-2 py-1 rounded-full" style={{ backgroundColor: getSubjectColor(rec.subject) }}>
                                        {rec.subject}
                                    </span>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </Card>
            </div>
        </div>
    );
};

export default StudentDashboard;