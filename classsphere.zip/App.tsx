import React, { useState, useCallback } from 'react';
import { useDarkMode } from './hooks/useDarkMode';
import { UserRole, Page, Student, Teacher } from './types';
import { STUDENTS, TEACHERS } from './constants';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import StudentDashboard from './components/StudentDashboard';
import StudyMode from './components/StudyMode';
import LessonPage from './components/LessonPage';
import AiTutor from './components/AiTutor';
import TeacherDashboard from './components/TeacherDashboard';

export default function App() {
    const [isDarkMode, toggleDarkMode] = useDarkMode();
    const [userRole, setUserRole] = useState<UserRole>('student');
    const [currentUser, setCurrentUser] = useState<Student | Teacher>(STUDENTS[0]);
    const [currentPage, setCurrentPage] = useState<Page>('dashboard');
    const [isTutorOpen, setTutorOpen] = useState(false);
    const [currentLesson, setCurrentLesson] = useState<{title: string, subject: string} | null>(null);

    const handleSetPage = useCallback((page: Page) => {
        setCurrentPage(page);
    }, []);

    const handleViewLesson = useCallback((lesson: {title: string, subject: string}) => {
        setCurrentLesson(lesson);
        setCurrentPage('lesson');
    }, []);
    
    const handleUserRoleChange = (role: UserRole) => {
        setUserRole(role);
        setCurrentPage('dashboard');
        if (role === 'student') {
            setCurrentUser(STUDENTS[0]);
        } else if (role === 'teacher') {
            setCurrentUser(TEACHERS[0]);
        }
    };

    const renderContent = () => {
        if (userRole === 'student') {
            const studentUser = currentUser as Student;
            switch (currentPage) {
                case 'dashboard':
                    return <StudentDashboard user={studentUser} setPage={handleSetPage} viewLesson={handleViewLesson} />;
                case 'study':
                    return <StudyMode setPage={handleSetPage} viewLesson={handleViewLesson} />;
                case 'lesson':
                    return <LessonPage lesson={currentLesson} setTutorOpen={setTutorOpen} />;
                default:
                    return <StudentDashboard user={studentUser} setPage={handleSetPage} viewLesson={handleViewLesson} />;
            }
        }
        if (userRole === 'teacher') {
            const teacherUser = currentUser as Teacher;
             switch (currentPage) {
                case 'dashboard':
                    return <TeacherDashboard user={teacherUser} />;
                default:
                    return <TeacherDashboard user={teacherUser} />;
            }
        }
        return null;
    };

    return (
        <div className={`flex h-screen bg-soft-grey dark:bg-charcoal font-sans transition-colors duration-300`}>
            <Sidebar userRole={userRole} currentPage={currentPage} setPage={handleSetPage} />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header 
                    user={currentUser} 
                    isDarkMode={isDarkMode} 
                    toggleDarkMode={toggleDarkMode}
                    userRole={userRole}
                    onRoleChange={handleUserRoleChange}
                />
                <main className="flex-1 overflow-x-hidden overflow-y-auto">
                    {renderContent()}
                </main>
            </div>
            {isTutorOpen && currentPage === 'lesson' && <AiTutor lesson={currentLesson} isOpen={isTutorOpen} setIsOpen={setTutorOpen} />}
        </div>
    );
}