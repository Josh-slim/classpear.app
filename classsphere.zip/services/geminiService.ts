import { GoogleGenAI, Type } from "@google/genai";
import { Student, StudyRecommendation, LessonPlan } from './types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const getTutorResponse = async (prompt: string, lessonContext: string) => {
  try {
    const fullPrompt = `
      You are an expert tutor for secondary school students, named ClassSphere AI. 
      A student is currently studying a lesson on "${lessonContext}". 
      Your tone should be friendly, encouraging, and mature.
      Answer their questions clearly and concisely.
      If a question is outside the scope of the lesson, gently guide them back to the topic or explain you can only help with the current subject.

      Student's question: "${prompt}"
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: fullPrompt,
    });

    return response.text;

  } catch (error) {
    console.error("Error getting response from Gemini:", error);
    return "I'm sorry, I'm having trouble connecting right now. Please try again in a moment.";
  }
};

export const getStudyPlan = async (student: Student): Promise<StudyRecommendation[]> => {
  try {
    const prompt = `
      You are an expert academic advisor AI for a secondary school student named ${student.name}.
      Create a personalized and actionable daily study plan for them.
      The plan should consist of 3-4 concrete tasks.
      For each task, provide a clear title, a brief description of why it's important, the subject it relates to, an estimated completion time (e.g., "20 minutes"), and a task type ('lesson', 'practice', 'quiz', or 'flashcards').
      The student is currently studying: Math, Physics, Biology, Chemistry, History, English.
      Focus on creating a balanced plan.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            studyPlan: {
              type: Type.ARRAY,
              description: 'The list of personalized study recommendations.',
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  subject: { type: Type.STRING },
                  description: { type: Type.STRING },
                  estimatedTime: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ['lesson', 'practice', 'quiz', 'flashcards'] },
                },
                required: ['title', 'subject', 'description', 'estimatedTime', 'type']
              }
            }
          }
        }
      }
    });

    const jsonResponse = JSON.parse(response.text);
    return jsonResponse.studyPlan.map((item: Omit<StudyRecommendation, 'id'>, index: number) => ({...item, id: `ai-rec-${index}`}));

  } catch (error) {
    console.error("Error getting study plan from Gemini:", error);
    return [
      { id: 'err-1', title: 'Review your notes', subject: 'Any', description: 'Solidify your knowledge by reviewing past notes.', estimatedTime: '20 min', type: 'lesson' },
      { id: 'err-2', title: 'Try some practice problems', subject: 'Math', description: 'Apply concepts to practice problems.', estimatedTime: '30 min', type: 'practice' },
    ];
  }
};


export const getLessonPlan = async (subject: string, topic: string, duration: string): Promise<LessonPlan | null> => {
  try {
    const prompt = `
      You are an expert curriculum designer for secondary school teachers.
      Create a detailed lesson plan for a class.
      The lesson is on the subject of "${subject}", with the topic "${topic}".
      The total duration for the lesson is ${duration}.
      The lesson plan should include:
      1. A list of 2-3 clear learning objectives.
      2. A list of key concepts to be covered.
      3. A list of engaging activities with descriptions and allocated times that add up to the total duration.
      4. A brief assessment method to check for understanding.
      Provide the output in a structured JSON format.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            learningObjectives: { type: Type.ARRAY, items: { type: Type.STRING } },
            keyConcepts: { type: Type.ARRAY, items: { type: Type.STRING } },
            activities: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  time: { type: Type.STRING },
                },
                required: ['name', 'description', 'time']
              }
            },
            assessment: { type: Type.STRING },
          },
          required: ['learningObjectives', 'keyConcepts', 'activities', 'assessment']
        }
      }
    });

    return JSON.parse(response.text);

  } catch (error) {
    console.error("Error getting lesson plan from Gemini:", error);
    // Fallback data
    return {
      learningObjectives: ["Understand the concept of a fallback.", "Learn to handle API errors gracefully."],
      keyConcepts: ["Error Handling", "Mock Data", "User Experience"],
      activities: [
        { name: "API Call Simulation", description: "Simulate a failed API call to trigger the fallback.", time: "10 minutes" },
        { name: "Review Fallback Code", description: "Analyze the code that provides mock data when an error occurs.", time: "15 minutes" },
      ],
      assessment: "Explain why providing fallback data is important for user experience."
    };
  }
};
