export type UserRole = 'student' | 'teacher' | 'admin';

export type Page = 'dashboard' | 'live' | 'study' | 'assignments' | 'grades' | 'materials' | 'tests' | 'profile' | 'lesson';

export interface User {
    id: string;
    name: string;
    avatarUrl: string;
}

export interface Student extends User {}
export interface Teacher extends User {}

export interface Course {
    id:string;
    subject: string;
    time: string;
    teacher: string;
}

export interface Assignment {
    id: string;
    title: string;
    dueDate: string;
    course: string;
}

export interface StudyRecommendation {
    id: string;
    title: string;
    type: 'lesson' | 'flashcards' | 'practice' | 'quiz';
    progress?: number;
    subject: string;
    description: string;
    estimatedTime: string;
}

export interface LessonPlan {
    learningObjectives: string[];
    keyConcepts: string[];
    activities: {
        name: string;
        description: string;
        time: string;
    }[];
    assessment: string;
}
