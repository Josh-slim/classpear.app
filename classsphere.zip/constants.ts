
import { Student, Teacher, Course, Assignment } from './types';

export const STUDENTS: Student[] = [
    { id: 's1', name: 'Alex', avatarUrl: 'https://picsum.photos/seed/alex/100/100' }
];

export const TEACHERS: Teacher[] = [
    { id: 't1', name: 'Ms. Daniels', avatarUrl: 'https://picsum.photos/seed/daniels/100/100' }
];

export const SCHEDULE: Course[] = [
    { id: 'c1', subject: 'Math', time: '1:00 PM', teacher: 'Mr. Armstrong' },
    { id: 'c2', subject: 'Chemistry', time: '3:00 PM', teacher: 'Ms. Curie' }
];

export const ASSIGNMENTS: Assignment[] = [
    { id: 'a1', title: 'Literature Essay', dueDate: 'Tomorrow', course: 'English' }
];

export const SUBJECTS = ['Math', 'Physics', 'Biology', 'Chemistry', 'History', 'English'];

export const CONTINUE_LEARNING = { subject: 'Physics', topic: 'Forces', progress: 65 };

export const RECOMMENDED_TODAY = [
    { id: 'rt1', title: '10 practice questions', subject: 'Math' },
    { id: 'rt2', title: 'Review flashcards', subject: 'English' }
];

export const LESSON_CONTENT = {
    title: 'Algebra - Linear Equations',
    subject: 'Math',
    components: [
        'Lesson Objectives',
        'Video (12 min)',
        'Key Notes',
        'Worked Examples',
        'Practice Questions (10)',
        'Mini Quiz (5 Questions)',
        'Summary Flashcards'
    ]
};